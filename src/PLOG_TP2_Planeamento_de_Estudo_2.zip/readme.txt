O solver encontra-se no ficheiro study_plan.pl e o predicado inicial encontra-se em study(Students) que deve receber uma
lista com os nomes de todos os estudantes da base de conhecimento. O ficheiro study_statistics contem predicados para 
a realização de estatisticas, sendo que basta mudar o ficheiro incluido na linha 2 para alterar a dimensão da base de 
conhecimento.